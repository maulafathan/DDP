import streamlit as st

# Fungsi untuk halaman utama
def display_home():
    st.title("Selamat Datang di Aplikasi Laundry Sederhana")
    st.write("Gunakan menu di sebelah kiri untuk menjelajahi fitur aplikasi.")
